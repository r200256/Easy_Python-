import fast

place = fast.pick()
print("Let's go to", place)
