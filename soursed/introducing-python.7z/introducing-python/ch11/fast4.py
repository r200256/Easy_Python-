from fast import pick

place = pick()
print("Let's go to", place)
