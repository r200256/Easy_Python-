import fast as f

place = f.pick()
print("Let's go to", place)
