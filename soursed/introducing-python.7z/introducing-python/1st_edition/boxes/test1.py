print("This standalone program works!")
