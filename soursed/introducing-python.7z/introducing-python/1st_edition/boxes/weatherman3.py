from report import get_description
description = get_description()
print("Today's weather:", description)
