import sys
print('Program arguments:', sys.argv)
