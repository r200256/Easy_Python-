from fabric.api import run

def iso():
    run('date -u')
