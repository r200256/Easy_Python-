def just_do_it(text):
    "Capitalize all words in <text>"
    return text.capitalize()
