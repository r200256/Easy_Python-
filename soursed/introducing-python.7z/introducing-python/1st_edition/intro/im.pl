my $language = 4;
print "Language $language: I am Perl, the camel of languages.\n";
