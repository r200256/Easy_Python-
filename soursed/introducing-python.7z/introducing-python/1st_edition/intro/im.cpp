#include <iostream>
using namespace std;
int main() {
    int language = 2;
    cout << "Language " << language << \
       ": I am C++!  Pay no attention to that C behind the curtain!" << \
       endl;
    return(0);
}
