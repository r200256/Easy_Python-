language = 5
puts "Language #{language}: I am Ruby, ready and aglow."
