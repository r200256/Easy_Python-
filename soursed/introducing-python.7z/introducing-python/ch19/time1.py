from time import time

t1 = time()
num = 5
num *= 2
print(time() - t1)
