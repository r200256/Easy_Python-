Introducing Python -- Second Edition
=================

This repository contains the programs featured in 
the second edition of the book _Introducing Python_.
